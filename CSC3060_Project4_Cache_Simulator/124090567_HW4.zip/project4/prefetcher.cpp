#include "prefetcher.h"

std::vector<uint64_t> NextLinePrefetcher::calculatePrefetch(uint64_t current_addr, bool miss) {
    (void)miss;
    std::vector<uint64_t> prefetches;
    // Align down to block boundary, then prefetch next block
    uint64_t current_block = (current_addr / block_size) * block_size;
    prefetches.push_back(current_block + block_size);
    return prefetches;
}

std::vector<uint64_t> StridePrefetcher::calculatePrefetch(uint64_t current_addr, bool miss) {
    (void)miss;
    std::vector<uint64_t> prefetches;

    uint64_t current_block = current_addr / block_size;

    if (has_last_block) {
        int64_t stride = (int64_t)current_block - (int64_t)last_block;
        if (stride != 0) {
            if (stride == last_stride) {
                if (confidence < 4) confidence++;
            } else {
                last_stride = stride;
                confidence = 1;
            }
            if (confidence >= 2) {
                uint64_t prefetch_block = current_block + stride;
                prefetches.push_back(prefetch_block * block_size);
            }
        }
    }

    last_block = current_block;
    has_last_block = true;
    return prefetches;
}

Prefetcher* createPrefetcher(std::string name, uint32_t block_size) {
    if (name == "NextLine") return new NextLinePrefetcher(block_size);
    if (name == "Stride")   return new StridePrefetcher(block_size);
    return new NoPrefetcher();
}
