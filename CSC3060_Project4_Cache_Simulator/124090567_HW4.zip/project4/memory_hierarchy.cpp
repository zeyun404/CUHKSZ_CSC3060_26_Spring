#include "memory_hierarchy.h"
#include "prefetcher.h"
#include "repl_policy.h"
#include <cmath>
#include <iomanip>
#include <iostream>

using namespace std;

// ==========================================
// MainMemory
// ==========================================

MainMemory::MainMemory(int lat) : latency(lat) {}

int MainMemory::access(uint64_t addr, char type, uint64_t cycle) {
    (void)addr;
    (void)type;
    (void)cycle;
    access_count++;
    return latency;
}

void MainMemory::printStats() {
    cout << "  [Main Memory] Total Accesses: " << access_count << endl;
}

// ==========================================
// CacheLevel
// ==========================================

CacheLevel::CacheLevel(string name, CacheConfig cfg, MemoryObject* next)
    : level_name(name), config(cfg), next_level(next) {
    policy    = createReplacementPolicy(config.policy_name);
    prefetcher = createPrefetcher(config.prefetcher, config.block_size);

    uint64_t total_bytes = (uint64_t)config.size_kb * 1024;
    num_sets   = total_bytes / (config.block_size * config.associativity);
    offset_bits = (uint32_t)log2(config.block_size);
    index_bits  = (uint32_t)log2(num_sets);

    sets.resize(num_sets, vector<CacheLine>(config.associativity));

    cout << "Constructed " << level_name << ": "
         << config.size_kb << "KB, " << config.associativity << "-way, "
         << config.latency << "cyc, "
         << "[" << config.policy_name << " + " << prefetcher->getName() << "]" << endl;
}

CacheLevel::~CacheLevel() {
    delete policy;
    delete prefetcher;
}

uint64_t CacheLevel::get_index(uint64_t addr) {
    // Remove block offset, then mask index bits
    uint64_t index_mask = (1ULL << index_bits) - 1;
    return (addr >> offset_bits) & index_mask;
}

uint64_t CacheLevel::get_tag(uint64_t addr) {
    // Shift away both offset and index bits
    return addr >> (offset_bits + index_bits);
}

uint64_t CacheLevel::reconstruct_addr(uint64_t tag, uint64_t index) {
    // Rebuild block-aligned address (offset bits are zero)
    return (tag << (offset_bits + index_bits)) | (index << offset_bits);
}

void CacheLevel::write_back_victim(const CacheLine& line, uint64_t index, uint64_t cycle) {
    if (!line.dirty) return;
    if (!next_level) return;
    write_backs++;
    uint64_t wb_addr = reconstruct_addr(line.tag, index);
    next_level->access(wb_addr, 'w', cycle);
}

int CacheLevel::access(uint64_t addr, char type, uint64_t cycle) {
    int lat = config.latency;

    uint64_t index = get_index(addr);
    uint64_t tag   = get_tag(addr);
    vector<CacheLine>& set = sets[index];

    // --- Hit detection ---
    for (int i = 0; i < (int)config.associativity; i++) {
        if (set[i].valid && set[i].tag == tag) {
            // HIT
            hits++;
            policy->onHit(set, i, cycle);
            if (type == 'w') set[i].dirty = true;
            set[i].is_prefetched = false;
            // Prefetcher notification
            auto pf_addrs = prefetcher->calculatePrefetch(addr, false);
            for (uint64_t pf : pf_addrs) {
                install_prefetch(pf, cycle);
            }
            return lat;
        }
    }

    // --- Miss ---
    misses++;
    lat += next_level->access(addr, 'r', cycle); // fetch from next level

    // Find a free slot or evict
    int victim_way = -1;
    for (int i = 0; i < (int)config.associativity; i++) {
        if (!set[i].valid) { victim_way = i; break; }
    }
    if (victim_way == -1) {
        victim_way = policy->getVictim(set);
        write_back_victim(set[victim_way], index, cycle);
    }

    // Install new line
    set[victim_way].tag          = tag;
    set[victim_way].valid        = true;
    set[victim_way].dirty        = (type == 'w');
    set[victim_way].is_prefetched = false;
    policy->onMiss(set, victim_way, cycle);

    // Prefetcher notification on miss
    auto pf_addrs = prefetcher->calculatePrefetch(addr, true);
    for (uint64_t pf : pf_addrs) {
        install_prefetch(pf, cycle);
    }

    return lat;
}

void CacheLevel::install_prefetch(uint64_t addr, uint64_t cycle) {
    uint64_t index = get_index(addr);
    uint64_t tag   = get_tag(addr);
    vector<CacheLine>& set = sets[index];

    // Already present? Don't prefetch again
    for (int i = 0; i < (int)config.associativity; i++) {
        if (set[i].valid && set[i].tag == tag) return;
    }

    prefetch_issued++;

    // Fetch from next level (prefetch is a read)
    next_level->access(addr, 'r', cycle);

    // Find slot
    int victim_way = -1;
    for (int i = 0; i < (int)config.associativity; i++) {
        if (!set[i].valid) { victim_way = i; break; }
    }
    if (victim_way == -1) {
        victim_way = policy->getVictim(set);
        write_back_victim(set[victim_way], index, cycle);
    }

    set[victim_way].tag           = tag;
    set[victim_way].valid         = true;
    set[victim_way].dirty         = false;
    set[victim_way].is_prefetched = true;
    policy->onMiss(set, victim_way, cycle);
}

void CacheLevel::printStats() {
    uint64_t total = hits + misses;
    cout << "  [" << level_name << "] "
         << "Hit Rate: " << fixed << setprecision(2)
         << (total ? (double)hits / total * 100.0 : 0) << "% "
         << "(Access: " << total << ", Miss: " << misses << ", WB: " << write_backs << ")" << endl;
    cout << "      Prefetches Issued: " << prefetch_issued << endl;
}
