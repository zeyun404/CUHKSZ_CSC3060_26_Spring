#include "repl_policy.h"
#include <climits>

// =========================================================
// LRU Policy
// =========================================================

void LRUPolicy::onHit(std::vector<CacheLine>& set, int way, uint64_t cycle) {
    set[way].last_access = cycle;
}

void LRUPolicy::onMiss(std::vector<CacheLine>& set, int way, uint64_t cycle) {
    set[way].last_access = cycle;
}

int LRUPolicy::getVictim(std::vector<CacheLine>& set) {
    int victim = 0;
    uint64_t oldest = set[0].last_access;
    for (int i = 1; i < (int)set.size(); i++) {
        if (set[i].last_access < oldest) {
            oldest = set[i].last_access;
            victim = i;
        }
    }
    return victim;
}

// =========================================================
// SRRIP Policy
// Re-Reference Prediction Value: 0=near, 3=far (evict at 3)
// On miss: insert at RRPV=2
// On hit:  promote to RRPV=0
// Victim:  find RRPV==3, if none age all by +1 and retry
// =========================================================

void SRRIPPolicy::onHit(std::vector<CacheLine>& set, int way, uint64_t cycle) {
    (void)cycle;
    set[way].rrpv = 0;
}

void SRRIPPolicy::onMiss(std::vector<CacheLine>& set, int way, uint64_t cycle) {
    (void)cycle;
    set[way].rrpv = 2;
}

int SRRIPPolicy::getVictim(std::vector<CacheLine>& set) {
    while (true) {
        for (int i = 0; i < (int)set.size(); i++) {
            if (set[i].rrpv == 3) return i;
        }
        // Age all lines
        for (auto& line : set) {
            line.rrpv++;
        }
    }
}

// =========================================================
// BIP Policy (Bimodal Insertion Policy)
// Mostly inserts at LRU position (RRPV=2 equivalent / old timestamp)
// Occasionally inserts at MRU position (1/throttle times)
// Hit behavior same as LRU
// =========================================================

void BIPPolicy::onHit(std::vector<CacheLine>& set, int way, uint64_t cycle) {
    set[way].last_access = cycle;
}

void BIPPolicy::onMiss(std::vector<CacheLine>& set, int way, uint64_t cycle) {
    insertion_counter++;
    if (insertion_counter % throttle == 0) {
        // MRU insertion (bimodal)
        set[way].last_access = cycle;
    } else {
        // LRU insertion: set timestamp to 0 (oldest)
        set[way].last_access = 0;
    }
}

int BIPPolicy::getVictim(std::vector<CacheLine>& set) {
    int victim = 0;
    uint64_t oldest = set[0].last_access;
    for (int i = 1; i < (int)set.size(); i++) {
        if (set[i].last_access < oldest) {
            oldest = set[i].last_access;
            victim = i;
        }
    }
    return victim;
}

ReplacementPolicy* createReplacementPolicy(std::string name) {
    if (name == "SRRIP") return new SRRIPPolicy();
    if (name == "BIP")   return new BIPPolicy();
    return new LRUPolicy();
}
