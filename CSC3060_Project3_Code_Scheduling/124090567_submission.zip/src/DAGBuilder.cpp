#include "DAGBuilder.h"

#include <iomanip>
#include <iostream>
#include <set>

std::vector<DAGNode> DAGBuilder::build(const std::vector<Instruction>& instructions) {
    std::vector<DAGNode> nodes;
    nodes.reserve(instructions.size());

    for (size_t i = 0; i < instructions.size(); i++) {
        nodes.emplace_back(static_cast<int>(i));
    }

    // One-pass: detect RAW, WAR, WAW simultaneously
    std::map<std::string, int> lastWriter;
    std::map<std::string, std::vector<int>> lastReaders;

    for (size_t i = 0; i < instructions.size(); i++) {
        const Instruction& inst = instructions[i];

        // 先处理读操作
        for (const auto& srcReg : inst.src_regs) {
            // RAW：如果之前有写过这个寄存器
            auto wIt = lastWriter.find(srcReg);
            if (wIt != lastWriter.end()) {
                addEdge(nodes, wIt->second, static_cast<int>(i), DependencyType::RAW, srcReg);
            }
            // 记录自己为reader
            lastReaders[srcReg].push_back(static_cast<int>(i));
        }

        // 再处理写操作
        if (inst.hasDestReg()) {
    const std::string& dest = inst.dest_reg;

    auto wIt = lastWriter.find(dest);
    if (wIt != lastWriter.end()) {
        addEdge(nodes, wIt->second, static_cast<int>(i), DependencyType::WAW, dest);
    }

    auto rIt = lastReaders.find(dest);
    if (rIt != lastReaders.end()) {
        for (int readerIdx : rIt->second) {
            if (readerIdx != static_cast<int>(i)) {  // ← 加这个检查，跳过自己
                addEdge(nodes, readerIdx, static_cast<int>(i), DependencyType::WAR, dest);
            }
        }
        rIt->second.clear();
    }

    lastWriter[dest] = static_cast<int>(i);
}    
    }

    for (auto& node : nodes) {
        node.unscheduled_predecessors = static_cast<int>(node.predecessors.size());
    }

    return nodes;
}

// Optimization: Only need to track the last write to each register
void DAGBuilder::detectRAW(const std::vector<Instruction>& instructions,
                           std::vector<DAGNode>& nodes) {
    std::map<std::string, int> lastWriter;

    for (size_t i = 0; i < instructions.size(); i++) {
        const Instruction& inst = instructions[i];

        for (const auto& srcReg : inst.src_regs) {
            auto it = lastWriter.find(srcReg);
            if (it != lastWriter.end()) {
                // Found RAW dependency
                int writerIdx = it->second;
                addEdge(nodes, writerIdx, static_cast<int>(i), DependencyType::RAW, srcReg);
            }
        }

        // Update last writer
        if (inst.hasDestReg()) {
            lastWriter[inst.dest_reg] = static_cast<int>(i);
        }
    }
}

void DAGBuilder::detectWAR(const std::vector<Instruction>& instructions,
                           std::vector<DAGNode>& nodes) {
    std::map<std::string, std::vector<int>> lastReaders;

    for (size_t i = 0; i < instructions.size(); ++i) {
        const Instruction& inst = instructions[i];

        // 第一步：处理写操作 → 找之前的readers，加WAR边，然后清空
        if (inst.hasDestReg()) {
            auto it = lastReaders.find(inst.dest_reg);
            if (it != lastReaders.end()) {
                for (int readerIdx : it->second) {
                    addEdge(nodes, readerIdx, static_cast<int>(i), DependencyType::WAR, inst.dest_reg);
                }
                it->second.clear();
            }
        }

        // 第二步：处理读操作 → 记录自己为reader
        for (const auto& srcReg : inst.src_regs) {
            lastReaders[srcReg].push_back(static_cast<int>(i));
        }
    }
}
    // TODO: Implement this function
    // Hint:
    // You need Track all readers of each register (after the last write)
    // Iterate each instruction, If current instruction writes a register, check previous readers
    // Add WAR dependency to all previous readers
    // WAR latency is 0 because read happens at instruction start

void DAGBuilder::detectWAW(const std::vector<Instruction>& instructions,
                           std::vector<DAGNode>& nodes) {
    std::map<std::string, int> lastWriter;

    for (size_t i = 0; i < instructions.size(); ++i) {
        const Instruction& inst = instructions[i];

        if (inst.hasDestReg()) {
            auto it = lastWriter.find(inst.dest_reg);
            if (it != lastWriter.end()) {
                addEdge(nodes, it->second, static_cast<int>(i), DependencyType::WAW, inst.dest_reg);
            }
            lastWriter[inst.dest_reg] = static_cast<int>(i);
        }
    }
}
    // TODO: Implement this function
    // Hint:
    // Track the last instruction that wrote to each register
    // WAW latency is 1, only need to guarantee order

void DAGBuilder::addEdge(
    std::vector<DAGNode>& nodes, int from, int to, DependencyType type, const std::string& reg) {
    for (const auto& edge : nodes[from].successors) {
        if (edge.target_node == to && edge.type == type && edge.reg == reg) {
            return;  // Edge already exists
        }
    }

    // from -> to
    nodes[from].successors.emplace_back(to, type, reg);

    // to <- from
    nodes[to].predecessors.emplace_back(from, type, reg);
}

void DAGBuilder::printDAG(const std::vector<DAGNode>& nodes,
                          const std::vector<Instruction>& instructions,
                          std::ostream& os) {
    os << "\n";
    os << "Dependency Graph (DAG)\n";
    os << "  [ <- ] Predecessors (instructions that must be completed first):\n";
    os << "  [ -> ] Successors (instructions that depend on this instruction):\n";
    os << "\n";

    for (size_t i = 0; i < nodes.size(); i++) {
        const auto& node = nodes[i];
        os << "Instruction " << i << ": " << instructions[i].raw_text << "\n";

        if (!node.predecessors.empty()) {
            for (const auto& edge : node.predecessors) {
                os << "   <- [" << edge.target_node << "] " << dependencyTypeToString(edge.type)
                   << " on " << edge.reg << "\n";
            }
        }

        if (!node.successors.empty()) {
            for (const auto& edge : node.successors) {
                os << "    -> [" << edge.target_node << "] " << dependencyTypeToString(edge.type)
                   << " on " << edge.reg << "\n";
            }
        }

        if (node.predecessors.empty() && node.successors.empty()) {
            os << "  (no dependencies)\n";
        }

        os << "\n";
    }
}
