#include "Scheduler.h"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>

ScheduleResult Scheduler::schedule(const std::vector<Instruction>& instructions,
                                   std::vector<DAGNode>& nodes,
                                   TieBreakingPolicy policy) {
    ScheduleResult result;
    if (instructions.empty()) return result;

    // 先计算优先级
    computePriorities(instructions, nodes);

    int n = static_cast<int>(instructions.size());
    // inflight: (finish_cycle, node_idx)
    std::vector<std::pair<int,int> > inflight;
    int cycle = 0;

    while (static_cast<int>(result.order.size()) < n) {
        // 获取ready nodes并选最优
        auto ready = getReadyNodes(nodes);

        if (!ready.empty()) {
            int best = selectBestNode(ready, nodes, instructions, policy);
            nodes[best].scheduled = true;
            nodes[best].schedule_cycle = cycle;
            result.order.push_back(best);

            int finishCycle = cycle + instructions[best].latency;
            inflight.push_back(std::make_pair(finishCycle, best));

            // WAR/WAW后继：issued即释放
            for (const auto& edge : nodes[best].successors) {
                if (edge.type == DependencyType::WAR || edge.type == DependencyType::WAW) {
                    nodes[edge.target_node].unscheduled_predecessors--;
                }
            }
        }

        cycle++;

        // 处理inflight：retire完成的指令，释放RAW后继
        for (auto it = inflight.begin(); it != inflight.end(); ) {
            if (it->first == cycle) {
                int doneNode = it->second;
                for (const auto& edge : nodes[doneNode].successors) {
                    if (edge.type == DependencyType::RAW) {
                        nodes[edge.target_node].unscheduled_predecessors--;
                    }
                }
                it = inflight.erase(it);
            } else {
                ++it;
            }
        }
    }

    result.total_cycles = cycle;
    return result;
}

// 在 Scheduler.cpp 中替换 scheduleFast 部分
ScheduleResult Scheduler::scheduleFast(const std::vector<Instruction>& instructions,
                                       std::vector<DAGNode>& nodes,
                                       TieBreakingPolicy policy,
                                       bool verbose) {
    ScheduleResult result;
    if (instructions.empty()) return result;

    computePriorities(instructions, nodes);
    int n = static_cast<int>(instructions.size());
    result.order.reserve(n);

    // 1. Ready Queue 比较器
    auto cmp = [&](int a, int b) {
        if (nodes[a].priority != nodes[b].priority)
            return nodes[a].priority < nodes[b].priority;
        if (policy == TieBreakingPolicy::MOST_CHILD) {
            if (nodes[a].successors.size() != nodes[b].successors.size())
                return nodes[a].successors.size() < nodes[b].successors.size();
        } else if (policy == TieBreakingPolicy::LPT) {
            if (instructions[a].latency != instructions[b].latency)
                return instructions[a].latency < instructions[b].latency;
        }
        return a > b; 
    };
    std::priority_queue<int, std::vector<int>, decltype(cmp)> readyPQ(cmp);

    // 2. 使用最稳健的方式定义 Inflight Queue (避免 >> 符号问题)
    typedef std::pair<int, int> IPair;
    std::priority_queue<IPair, std::vector<IPair>, std::greater<IPair> > inflightPQ;

    for (int i = 0; i < n; i++) {
        if (nodes[i].unscheduled_predecessors == 0) {
            readyPQ.push(i);
        }
    }

    int cycle = 0;
    int scheduled_count = 0;
    while (scheduled_count < n) {
        // Retire: 释放 RAW
        while (!inflightPQ.empty() && inflightPQ.top().first <= cycle) {
            int doneNode = inflightPQ.top().second;
            inflightPQ.pop();
            for (const auto& edge : nodes[doneNode].successors) {
                if (edge.type == DependencyType::RAW) {
                    if (--nodes[edge.target_node].unscheduled_predecessors == 0)
                        readyPQ.push(edge.target_node);
                }
            }
        }

        // Issue: 释放 WAR/WAW
        if (!readyPQ.empty()) {
            int best = readyPQ.top();
            readyPQ.pop();
            nodes[best].scheduled = true;
            nodes[best].schedule_cycle = cycle;
            result.order.push_back(best);
            scheduled_count++;
            inflightPQ.push(std::make_pair(cycle + instructions[best].latency, best));

            for (const auto& edge : nodes[best].successors) {
                if (edge.type != DependencyType::RAW) {
                    if (--nodes[edge.target_node].unscheduled_predecessors == 0)
                        readyPQ.push(edge.target_node);
                }
            }
        }
        cycle++;
        // 性能加速点：如果没有 ready 但有正在运行的，直接跳到下一个完成时刻
        if (readyPQ.empty() && !inflightPQ.empty() && scheduled_count < n) {
            if (inflightPQ.top().first > cycle) cycle = inflightPQ.top().first;
        }
    }
    result.total_cycles = cycle;
    return result;
}

void Scheduler::computePriorities(const std::vector<Instruction>& instructions,
                                  std::vector<DAGNode>& nodes) {
    std::vector<bool> visited(nodes.size(), false);

    for (size_t i = 0; i < nodes.size(); i++) {
        if (!visited[i]) {
            computeCriticalPath(static_cast<int>(i), instructions, nodes, visited);
        }
    }
}

int Scheduler::computeCriticalPath(int nodeIdx,
                                   const std::vector<Instruction>& instructions,
                                   std::vector<DAGNode>& nodes,
                                   std::vector<bool>& visited) {
    if (visited[nodeIdx]) {
        return nodes[nodeIdx].priority;
    }
    visited[nodeIdx] = true;

    const DAGNode& node = nodes[nodeIdx];

    int rawMaxPriority = 0;
    int warwawMaxPriority = 0;

    for (const auto& edge : node.successors) {
        int succPriority = computeCriticalPath(edge.target_node, instructions, nodes, visited);
        if (edge.type == DependencyType::RAW) {
            rawMaxPriority = std::max(rawMaxPriority, succPriority);
        } else {
            warwawMaxPriority = std::max(warwawMaxPriority, succPriority);
        }
    }

    int priority = std::max(
        instructions[nodeIdx].latency + rawMaxPriority,
        warwawMaxPriority
    );

    nodes[nodeIdx].priority = priority;
    return priority;
}

std::vector<int> Scheduler::getReadyNodes(const std::vector<DAGNode>& nodes) {
    std::vector<int> ready;

    for (size_t i = 0; i < nodes.size(); i++) {
        if (!nodes[i].scheduled && nodes[i].unscheduled_predecessors == 0) {
            ready.push_back(static_cast<int>(i));
        }
    }

    return ready;
}

int Scheduler::selectBestNode(const std::vector<int>& readyNodes,
                              const std::vector<DAGNode>& nodes,
                              const std::vector<Instruction>& instructions,
                              TieBreakingPolicy policy) {
    int bestNode = readyNodes[0];
    int bestPriority = nodes[bestNode].priority;

    for (int nodeIdx : readyNodes) {
        int currentPriority = nodes[nodeIdx].priority;

        if (currentPriority > bestPriority) {
            bestPriority = currentPriority;
            bestNode = nodeIdx;
        } else if (currentPriority == bestPriority) {
            bool shouldReplace = false;

            switch (policy) {
                case TieBreakingPolicy::SMALLER_INDEX:
                    shouldReplace = (nodeIdx < bestNode);
                    break;
                case TieBreakingPolicy::MOST_CHILD:
                    if (nodes[nodeIdx].successors.size() > nodes[bestNode].successors.size()) {
                        shouldReplace = true;
                    } else if (nodes[nodeIdx].successors.size() == nodes[bestNode].successors.size()) {
                        shouldReplace = (nodeIdx < bestNode);
                    }
                    break;
                case TieBreakingPolicy::LPT:
                    if (instructions[nodeIdx].latency > instructions[bestNode].latency) {
                        shouldReplace = true;
                    } else if (instructions[nodeIdx].latency == instructions[bestNode].latency) {
                        shouldReplace = (nodeIdx < bestNode);
                    }
                    break;
            }

            if (shouldReplace) {
                bestNode = nodeIdx;
            }
        }
    }

    return bestNode;
}

void Scheduler::updateSuccessors(int nodeIdx, std::vector<DAGNode>& nodes) {
    for (const auto& edge : nodes[nodeIdx].successors) {
        int succIdx = edge.target_node;
        nodes[succIdx].unscheduled_predecessors--;
    }
}

void Scheduler::printSchedule(const ScheduleResult& result,
                              const std::vector<Instruction>& instructions,
                              const std::vector<DAGNode>& nodes,
                              std::ostream& os) {
    os << "\n";
    os << "Scheduling Result\n\n";

    os << "Original instruction order:\n";
    os << "─────────────────────────────────────────────────────────────────\n";
    for (size_t i = 0; i < instructions.size(); i++) {
        os << "  " << std::setw(2) << i << ": " << instructions[i].raw_text << "\n";
    }

    os << "\n";

    os << "Scheduled instruction order:\n";
    os << "─────────────────────────────────────────────────────────────────\n";
    for (size_t i = 0; i < result.order.size(); i++) {
        int instIdx = result.order[i];
        os << "  " << std::setw(2) << i << ": [Orig " << std::setw(2) << instIdx << "] "
           << instructions[instIdx].raw_text << " (priority: " << nodes[instIdx].priority << ")\n";
    }

    os << "\n";
    os << "Scheduling statistics:\n";
    os << "─────────────────────────────────────────────────────────────────\n";
    os << "  Instruction count: " << instructions.size() << "\n";
    os << "\n";
}

SimulationResult Scheduler::simulateExecution(const std::vector<int>& order,
                                              const std::vector<Instruction>& instructions,
                                              const std::vector<DAGNode>& nodes) {
    SimulationResult result;
    int n = static_cast<int>(instructions.size());

    result.start_cycle.resize(n, 0);
    result.end_cycle.resize(n, 0);

    std::vector<int> order_position(n, -1);
    for (size_t i = 0; i < order.size(); i++) {
        order_position[order[i]] = static_cast<int>(i);
    }

    for (int pos = 0; pos < static_cast<int>(order.size()); pos++) {
        int inst_idx = order[pos];
        const Instruction& inst = instructions[inst_idx];
        const DAGNode& node = nodes[inst_idx];

        int earliest_start = pos;

        for (const auto& pred_edge : node.predecessors) {
            int pred_idx = pred_edge.target_node;

            if (order_position[pred_idx] < pos) {
                int ready_time;
                if (pred_edge.type == DependencyType::RAW) {
                    ready_time = result.start_cycle[pred_idx] + instructions[pred_idx].latency;
                } else {
                    ready_time = result.start_cycle[pred_idx] + 1;
                }
                earliest_start = std::max(earliest_start, ready_time);
            }
        }

        result.start_cycle[inst_idx] = earliest_start;
        result.end_cycle[inst_idx] = earliest_start + inst.latency;
    }

    result.total_cycles = 0;
    for (int i = 0; i < n; i++) {
        result.total_cycles = std::max(result.total_cycles, result.end_cycle[i]);
    }

    return result;
}

void Scheduler::printComparison(const std::vector<Instruction>& instructions,
                                const std::vector<DAGNode>& nodes,
                                const ScheduleResult& scheduled_result,
                                std::ostream& os) {
    std::vector<int> original_order;
    for (size_t i = 0; i < instructions.size(); i++) {
        original_order.push_back(static_cast<int>(i));
    }

    SimulationResult original_sim = simulateExecution(original_order, instructions, nodes);
    SimulationResult scheduled_sim = simulateExecution(scheduled_result.order, instructions, nodes);

    os << "\n";
    os << "Scheduling Effectiveness Comparison\n\n";

    os << "Original order execution timeline:\n";
    os << "─────────────────────────────────────────────────────────────────\n";
    printTimeline(original_order, instructions, original_sim, os);

    os << "\n";

    os << "Scheduled order execution timeline:\n";
    os << "─────────────────────────────────────────────────────────────────\n";
    printTimeline(scheduled_result.order, instructions, scheduled_sim, os);

    os << "\n";

    os << "Performance comparison:\n";
    os << "─────────────────────────────────────────────────────────────────\n";
    os << "  Original order total cycles: " << original_sim.total_cycles << " cycles\n";
    os << "  Scheduled order total cycles: " << scheduled_sim.total_cycles << " cycles\n";

    int saved = original_sim.total_cycles - scheduled_sim.total_cycles;
    if (saved > 0) {
        double improvement = (static_cast<double>(saved) / original_sim.total_cycles) * 100.0;
        os << "  ─────────────────────────────────────────────────────────────\n";
        os << "  Cycles saved: " << saved << " cycles\n";
        os << "  Performance improvement: " << std::fixed << std::setprecision(1) << improvement
           << "%\n";
        os << "  ─────────────────────────────────────────────────────────────\n";
    } else if (saved < 0) {
        os << "  ─────────────────────────────────────────────────────────────\n";
        os << "  Note: Scheduled order cycles increased by " << (-saved) << " cycles\n";
        os << "  This may be because the original order was already optimal\n";
    } else {
        os << "  ─────────────────────────────────────────────────────────────\n";
        os << "  Same cycle count before and after scheduling, original order was already near "
              "optimal\n";
    }

    os << "\n";
}

void Scheduler::printTimeline(const std::vector<int>& order,
                              const std::vector<Instruction>& instructions,
                              const SimulationResult& sim,
                              std::ostream& os) {
    int max_cycle = sim.total_cycles;
    int timeline_width = std::min(max_cycle + 1, 40);

    os << "  Instruction" << std::string(14, ' ') << "Timeline (each unit=1 cycle)\n";
    os << "  " << std::string(26, ' ');

    for (int c = 0; c < timeline_width; c++) {
        if (c % 5 == 0) {
            os << c % 10;
        } else {
            os << " ";
        }
    }
    os << "\n";
    os << "  " << std::string(26, ' ') << std::string(timeline_width, '-') << "\n";

    for (int inst_idx : order) {
        const Instruction& inst = instructions[inst_idx];
        int start = sim.start_cycle[inst_idx];
        int end = sim.end_cycle[inst_idx];

        std::string inst_text = inst.raw_text;
        if (inst_text.length() > 20) {
            inst_text = inst_text.substr(0, 17) + "...";
        }

        os << "  [" << std::setw(2) << inst_idx << "] " << std::left << std::setw(20) << inst_text
           << std::right;

        for (int c = 0; c < timeline_width; c++) {
            if (c >= start && c < end) {
                os << "█";
            } else if (c < start) {
                os << "·";
            } else {
                os << " ";
            }
        }

        os << " [" << start << "-" << end << "]\n";
    }

    os << "  " << std::string(26, ' ') << std::string(timeline_width, '-') << "\n";
    os << "  Total execution cycles: " << max_cycle << " cycles\n";
}
